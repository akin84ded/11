package ru.mos2.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

import java.net.URI;
import java.net.URISyntaxException;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout setupPanel;
    private EditText serverUrl;
    private SharedPreferences prefs;
    private String pendingUrl = "";
    private Button notificationsButton;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 71;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        setupPanel = findViewById(R.id.setupPanel);
        serverUrl = findViewById(R.id.serverUrl);
        Button connect = findViewById(R.id.connectButton);
        Button reset = findViewById(R.id.resetButton);
        notificationsButton = findViewById(R.id.notificationsButton);

        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        configureWebView();
        updateNotificationsButton();
        notificationsButton.setVisibility(View.GONE);
        notificationsButton.setOnClickListener(v -> toggleNotifications());

        String saved = prefs.getString("server_url", "");
        if (!saved.isEmpty() && isAllowedServerUrl(saved)) {
            serverUrl.setText(saved);
            loadServer(saved);
        } else {
            prefs.edit().remove("server_url").apply();
            showSetup();
        }

        connect.setOnClickListener(v -> {
            String url = normalizeUrl(serverUrl.getText().toString().trim());
            if (!isAllowedServerUrl(url)) {
                Toast.makeText(this,
                    "Введите корректный HTTPS-адрес или локальный адрес HTTP (например, http://192.168.1.10:8501)",
                    Toast.LENGTH_LONG).show();
                return;
            }
            // Сохраняем адрес только после успешной загрузки главной страницы.
            loadServer(url);
        });

        reset.setOnClickListener(v -> {
            prefs.edit().remove("server_url").apply();
            WorkManager.getInstance(this).cancelUniqueWork("mos2_signal_poll");
            pendingUrl = "";
            webView.stopLoading();
            webView.loadUrl("about:blank");
            serverUrl.setText("");
            showSetup();
        });
    }

    private void configureWebView() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(false);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                if (!sameOrigin(pendingUrl, target.toString())) {
                    Toast.makeText(MainActivity.this,
                        "Переход на другой сайт заблокирован для безопасности.",
                        Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                setupPanel.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                if (sameOrigin(pendingUrl, url) && isAllowedServerUrl(url)) {
                    prefs.edit().putString("server_url", pendingUrl).apply();
                    if (prefs.getBoolean("notifications_enabled", false)) scheduleSignalChecks(pendingUrl);
                    notificationsButton.setVisibility(View.VISIBLE);
                    updateNotificationsButton();
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    prefs.edit().remove("server_url").apply();
                    pendingUrl = "";
                    Toast.makeText(MainActivity.this,
                        "Не удалось открыть сервер. Проверьте адрес, Wi-Fi и доступность порта 8501.",
                        Toast.LENGTH_LONG).show();
                    showSetup();
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    Toast.makeText(MainActivity.this,
                        "Ошибка сервера: HTTP " + response.getStatusCode(),
                        Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Никогда не принимаем недействительные сертификаты.
                handler.cancel();
                Toast.makeText(MainActivity.this,
                    "Ошибка сертификата HTTPS. Подключение отменено.",
                    Toast.LENGTH_LONG).show();
                showSetup();
            }
        });
    }

    private void toggleNotifications() {
        boolean enabled = prefs.getBoolean("notifications_enabled", false);
        if (enabled) {
            WorkManager.getInstance(this).cancelUniqueWork("mos2_signal_poll");
            prefs.edit().putBoolean("notifications_enabled", false).apply();
            Toast.makeText(this, "Уведомления отключены", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                return;
            }
            prefs.edit().putBoolean("notifications_enabled", true).apply();
            String saved = prefs.getString("server_url", "");
            if (!saved.isEmpty()) scheduleSignalChecks(saved);
            Toast.makeText(this, "Уведомления включены (проверка примерно раз в 15 минут)", Toast.LENGTH_LONG).show();
        }
        updateNotificationsButton();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("notifications_enabled", true).apply();
            String saved = prefs.getString("server_url", "");
            if (!saved.isEmpty()) scheduleSignalChecks(saved);
            updateNotificationsButton();
        } else if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            Toast.makeText(this, "Разрешите уведомления в настройках Android", Toast.LENGTH_LONG).show();
        }
    }

    private void updateNotificationsButton() {
        if (notificationsButton != null) {
            boolean enabled = prefs.getBoolean("notifications_enabled", false);
            notificationsButton.setText(enabled ? "Уведомления: вкл" : "Уведомления: выкл");
        }
    }

    private void scheduleSignalChecks(String server) {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        Data input = new Data.Builder().putString("server_url", server).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(SignalWorker.class, 15, TimeUnit.MINUTES)
            .setConstraints(constraints).setInputData(input).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("mos2_signal_poll",
            ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    private String normalizeUrl(String value) {
        if (value == null) return "";
        String url = value.trim();
        if (url.isEmpty()) return "";
        if (!url.matches("(?i)^https?://.*")) url = "http://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private boolean isAllowedServerUrl(String value) {
        try {
            URI uri = new URI(normalizeUrl(value));
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (host == null || uri.getUserInfo() != null || uri.getQuery() != null
                    || uri.getFragment() != null) return false;
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;
            if ("https".equalsIgnoreCase(scheme)) return true;
            // HTTP разрешён только для локального сервера в LAN.
            String h = host.toLowerCase();
            return "localhost".equals(h) || h.endsWith(".local") || isPrivateIpv4(h);
        } catch (URISyntaxException | IllegalArgumentException ex) {
            return false;
        }
    }

    private boolean isPrivateIpv4(String host) {
        String[] parts = host.split("\\.", -1);
        if (parts.length != 4) return false;
        int[] n = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                if (parts[i].isEmpty() || parts[i].length() > 3) return false;
                n[i] = Integer.parseInt(parts[i]);
                if (n[i] < 0 || n[i] > 255) return false;
            }
        } catch (NumberFormatException ex) {
            return false;
        }
        return n[0] == 10 || n[0] == 127
            || (n[0] == 192 && n[1] == 168)
            || (n[0] == 172 && n[1] >= 16 && n[1] <= 31)
            || (n[0] == 169 && n[1] == 254);
    }

    private boolean sameOrigin(String first, String second) {
        try {
            URI a = new URI(first);
            URI b = new URI(second);
            int pa = a.getPort() == -1 ? ("https".equals(a.getScheme()) ? 443 : 80) : a.getPort();
            int pb = b.getPort() == -1 ? ("https".equals(b.getScheme()) ? 443 : 80) : b.getPort();
            return a.getScheme() != null && b.getScheme() != null
                && a.getScheme().equalsIgnoreCase(b.getScheme())
                && a.getHost() != null && a.getHost().equalsIgnoreCase(b.getHost())
                && pa == pb;
        } catch (Exception ex) {
            return false;
        }
    }

    private void loadServer(String url) {
        String normalized = normalizeUrl(url);
        if (!isAllowedServerUrl(normalized)) {
            showSetup();
            return;
        }
        pendingUrl = normalized;
        webView.stopLoading();
        webView.setVisibility(View.VISIBLE);
        setupPanel.setVisibility(View.GONE);
        webView.loadUrl(normalized);
    }

    private void showSetup() {
        notificationsButton.setVisibility(View.GONE);
        webView.setVisibility(View.GONE);
        setupPanel.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE && webView.canGoBack()) {
            webView.goBack();
        } else if (webView.getVisibility() == View.VISIBLE) {
            showSetup();
        } else {
            super.onBackPressed();
        }
    }
}
