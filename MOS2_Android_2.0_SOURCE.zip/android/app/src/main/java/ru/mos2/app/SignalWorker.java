package ru.mos2.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Iterator;

public class SignalWorker extends Worker {
    private static final String CHANNEL = "mos2_signals";
    public SignalWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull @Override
    public Result doWork() {
        String server = getInputData().getString("server_url");
        if (server == null || server.isEmpty()) return Result.failure();
        HttpURLConnection connection = null;
        try {
            URI base = new URI(server);
            String endpoint;
            if ("http".equalsIgnoreCase(base.getScheme())) {
                endpoint = "http://" + base.getHost() + ":8502/api/signals";
            } else {
                int port = base.getPort();
                endpoint = base.getScheme() + "://" + base.getHost()
                    + (port == -1 ? "" : ":" + port) + "/api/signals";
            }
            connection = (HttpURLConnection)new URL(endpoint).openConnection();
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            if (connection.getResponseCode() != 200) return Result.retry();
            java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int count;
            while ((count = connection.getInputStream().read(chunk)) != -1) buffer.write(chunk, 0, count);
            JSONObject signals = new JSONObject(new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8));
            SharedPreferences prefs = getApplicationContext().getSharedPreferences("signal_state", Context.MODE_PRIVATE);
            boolean initialized = prefs.getBoolean("initialized", false);
            NotificationManager nm = (NotificationManager)getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Сигналы MOS2", NotificationManager.IMPORTANCE_DEFAULT));
            }
            Iterator<String> keys = signals.keys();
            while (keys.hasNext()) {
                String ticker = keys.next();
                JSONObject item = signals.optJSONObject(ticker);
                if (item == null) continue;
                String signal = item.optString("signal", "HOLD");
                String old = prefs.getString(ticker, null);
                if (initialized && old != null && !old.equals(signal) && ("BUY".equals(signal) || "SELL".equals(signal))) {
                    if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        String price = item.has("price") ? String.format(java.util.Locale.US, "%.2f", item.optDouble("price")) : "—";
                        Notification notification = new Notification.Builder(getApplicationContext(), CHANNEL)
                            .setSmallIcon(android.R.drawable.ic_dialog_info)
                            .setContentTitle("MOS2: " + ticker + " — " + signal)
                            .setContentText("Цена: " + price + " ₽")
                            .setAutoCancel(true).build();
                        nm.notify(ticker.hashCode(), notification);
                    }
                }
                prefs.edit().putString(ticker, signal).apply();
            }
            prefs.edit().putBoolean("initialized", true).apply();
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
