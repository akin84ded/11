from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
for xml in ROOT.glob("app/src/main/**/*.xml"):
    ET.parse(xml)

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
java = (ROOT / "app/src/main/java/ru/mos2/app/MainActivity.java").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle").read_text(encoding="utf-8")

required = {
    "Internet permission": "android.permission.INTERNET" in manifest,
    "No Android backup": 'android:allowBackup="false"' in manifest,
    "Private HTTP allowlist": "isPrivateIpv4(h)" in java and 'localhost'.lower() in java.lower(),
    "HTTPS certificate errors rejected": "handler.cancel()" in java,
    "Cross-origin navigation blocked": "sameOrigin(pendingUrl" in java,
    "Address saved only after page commit": "onPageCommitVisible" in java and 'putString("server_url", pendingUrl)' in java,
    "File access disabled": "setAllowFileAccess(false)" in java,
    "Content access disabled": "setAllowContentAccess(false)" in java,
    "Main-frame network errors handled": "onReceivedError" in java and "request.isForMainFrame()" in java,
    "HTTP errors surfaced": "onReceivedHttpError" in java,
    "Version 2.0.0": 'versionName "2.0.0"' in gradle,
    "Android notification permission": "android.permission.POST_NOTIFICATIONS" in manifest,
    "Background signal worker": (ROOT / "app/src/main/java/ru/mos2/app/SignalWorker.java").exists(),
    "Periodic WorkManager polling": "enqueueUniquePeriodicWork" in java,
}
for name, ok in required.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(required.values()):
    raise SystemExit(1)
print("ALL ANDROID STATIC CHECKS PASSED")
