import time, requests

class TelegramPoller:
    def __init__(self,token):
        self.token=token; self.offset=None
    def poll(self):
        p={"timeout":30,"limit":100}
        if self.offset is not None:p["offset"]=self.offset
        r=requests.get(f"https://api.telegram.org/bot{self.token}/getUpdates",params=p,timeout=40)
        r.raise_for_status()
        for u in r.json().get("result",[]):
            self.offset=u["update_id"]+1
            yield u

class MaxPoller:
    def __init__(self,token):
        self.token=token; self.marker=None
    def poll(self):
        p={"timeout":30,"limit":100,"types":"message_created,message_callback"}
        if self.marker is not None:p["marker"]=self.marker
        r=requests.get("https://platform-api2.max.ru/updates",
                       headers={"Authorization":self.token},params=p,timeout=40)
        r.raise_for_status(); js=r.json()
        if js.get("marker") is not None:self.marker=js["marker"]
        for u in js.get("updates",[]):yield u

def extract_command(channel,u):
    if channel=="telegram":
        msg=u.get("message",{}); txt=msg.get("text","") or ""
    else:
        msg=u.get("message",u.get("payload",{})) or {}
        txt=msg.get("text","") or msg.get("body",{}).get("text","") if isinstance(msg,dict) else ""
    txt=txt.strip()
    return txt

def command_help():
    return "/status — состояние\n/signals — сигналы\n/portfolio — портфель\n/add SBER — добавить\n/remove SBER — убрать\n/ping — проверка"
