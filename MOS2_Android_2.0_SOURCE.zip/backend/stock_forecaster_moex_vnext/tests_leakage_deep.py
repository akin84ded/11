import numpy as np
import pandas as pd

from analytics import indicators
from ml_model import dataset, _purged_split, walk_forward, fit_predict
from backtest import realistic_backtest
import moex

def make_prices(n=650, seed=123):
    rng=np.random.default_rng(seed)
    idx=pd.bdate_range("2021-01-04",periods=n)
    ret=rng.normal(0.0004,0.014,n)
    close=100*np.cumprod(1+ret)
    open_=np.r_[close[0],close[:-1]*(1+rng.normal(0,0.003,n-1))]
    high=np.maximum(open_,close)*(1+rng.uniform(0,0.01,n))
    low=np.minimum(open_,close)*(1-rng.uniform(0,0.01,n))
    volume=rng.integers(10000,1000000,n)
    return pd.DataFrame(
        {"OPEN":open_,"HIGH":high,"LOW":low,"CLOSE":close,"VOLUME":volume},
        index=idx
    )

raw=make_prices()
feat=indicators(raw)
FEATURE_CHECK=["RET_1","RET_5","SMA20","SMA50","SMA200","EMA20","RSI14",
               "MACD","MACD_SIGNAL","BB_UP","BB_DN","ATR14","OBV","VOL_Z","VOL_ANN"]

# 1) Strict causality of indicators.
cut_raw=420
mut=raw.copy()
mut.iloc[cut_raw+1:,mut.columns.get_loc("CLOSE")]*=7
mut.iloc[cut_raw+1:,mut.columns.get_loc("OPEN")]*=6
mut.iloc[cut_raw+1:,mut.columns.get_loc("HIGH")]*=8
mut.iloc[cut_raw+1:,mut.columns.get_loc("LOW")]*=5
mut.iloc[cut_raw+1:,mut.columns.get_loc("VOLUME")]*=9
feat_mut=indicators(mut)
pd.testing.assert_frame_equal(
    feat.iloc[:cut_raw+1][FEATURE_CHECK],
    feat_mut.iloc[:cut_raw+1][FEATURE_CHECK],
    check_exact=False,rtol=1e-12,atol=1e-12
)
print("PASS indicator causality")

# 2) Exact forward target.
h=20
d=dataset(feat,h)
assert len(d)>250
orig_pos={idx:i for i,idx in enumerate(feat.index)}
for idx in d.index[10:50:10]:
    p=orig_pos[idx]
    expected=feat["CLOSE"].iloc[p+h]/feat["CLOSE"].iloc[p]-1
    assert abs(float(d.loc[idx,"TARGET_RET"])-float(expected))<1e-12
print("PASS target definition")

# 3) Purged holdout: no training label reaches test period.
cut=max(h+50,int(len(d)*0.70))
tr,te=_purged_split(d,cut,h)
assert len(tr)==cut-h
assert len(te)==len(d)-cut
last_train_pos=orig_pos[tr.index[-1]]
test_start_pos=orig_pos[te.index[0]]
assert last_train_pos+h < test_start_pos
print("PASS purged holdout")

# 4) Mutating test/future region cannot alter purged training rows.
test_start_raw=orig_pos[te.index[0]]
raw_future_mut=raw.copy()
raw_future_mut.iloc[test_start_raw:,raw_future_mut.columns.get_loc("CLOSE")]*=4
raw_future_mut.iloc[test_start_raw:,raw_future_mut.columns.get_loc("OPEN")]*=3
raw_future_mut.iloc[test_start_raw:,raw_future_mut.columns.get_loc("HIGH")]*=5
raw_future_mut.iloc[test_start_raw:,raw_future_mut.columns.get_loc("LOW")]*=2
feat_future_mut=indicators(raw_future_mut)
d2=dataset(feat_future_mut,h)
# Select exact original training timestamps; they must be identical.
tr2=d2.loc[tr.index]
pd.testing.assert_frame_equal(
    tr[FEATURE_CHECK+["TARGET_RET","TARGET_UP"]],
    tr2[FEATURE_CHECK+["TARGET_RET","TARGET_UP"]],
    check_exact=False,rtol=1e-12,atol=1e-12
)
print("PASS future mutation cannot contaminate train")

# 5) fit_predict exposes purge accounting.
fp=fit_predict(feat,horizon=h,test_size=.2,random_state=7)
assert fp["metrics"]["purge_rows"]==h
assert fp["metrics"]["train_rows"]>0
assert fp["metrics"]["test_rows"]>0
print("PASS fit_predict purge")

# 6) Walk-forward boundaries are purged.
wf=walk_forward(feat,horizon=h,min_train=200,step=20)
assert not wf.empty
assert (wf["purge_rows"]==h).all()
for _,row in wf.iterrows():
    lp=orig_pos[pd.Timestamp(row["train_end"])]
    sp=orig_pos[pd.Timestamp(row["test_start"])]
    assert lp+h < sp
print("PASS purged walk-forward")

# 7) Same-day OPEN cannot influence an order generated at same-day CLOSE.
bt=raw.iloc[:20].copy()
bt["SIGNAL"]=0.0
bt.iloc[5,bt.columns.get_loc("SIGNAL")]=1.0
base_res=realistic_backtest(bt,execution_delay=1,commission=0,slippage=0,initial_cash=100000)
same_day=bt.copy()
same_day.iloc[5,same_day.columns.get_loc("OPEN")]*=1000
same_day_res=realistic_backtest(same_day,execution_delay=1,commission=0,slippage=0,initial_cash=100000)
pd.testing.assert_series_equal(base_res["equity"],same_day_res["equity"])
print("PASS no same-day execution leakage")

# 8) Next-day OPEN must influence execution.
next_day=bt.copy()
next_day.iloc[6,next_day.columns.get_loc("OPEN")]*=1.5
next_day_res=realistic_backtest(next_day,execution_delay=1,commission=0,slippage=0,initial_cash=100000)
assert not np.allclose(base_res["equity"].values,next_day_res["equity"].values)
print("PASS delayed next-open execution")

# 9) Costs cannot improve identical strategy equity.
cost_res=realistic_backtest(bt,execution_delay=1,commission=.001,slippage=.001,initial_cash=100000)
assert cost_res["final_equity"] <= base_res["final_equity"] + 1e-9
assert cost_res["cost_total"]>0
print("PASS trading cost direction")

# 10) MOEX: history block, not cursor, and pagination.
orig_get=moex._get
def fake_get(path,params=None,retries=3,timeout=20):
    start=int((params or {}).get("start",0))
    if start==0:
        return {
          "history":{"columns":["TRADEDATE","BOARDID","OPEN","HIGH","LOW","CLOSE","VOLUME"],
                     "data":[["2025-01-01","TQBR",100,102,99,101,1000],
                             ["2025-01-02","TQBR",101,103,100,102,1100]]},
          "history.cursor":{"columns":["INDEX","TOTAL","PAGESIZE"],"data":[[0,3,2]]}}
    return {
      "history":{"columns":["TRADEDATE","BOARDID","OPEN","HIGH","LOW","CLOSE","VOLUME"],
                 "data":[["2025-01-03","TQBR",102,104,101,103,1200]]},
      "history.cursor":{"columns":["INDEX","TOTAL","PAGESIZE"],"data":[[2,3,2]]}}
moex._get=fake_get
try:
    mh=moex.history("SBER",board="TQBR",session=None)
    assert len(mh)==3
    assert list(mh["CLOSE"])==[101,102,103]
finally:
    moex._get=orig_get
print("PASS MOEX history pagination/parser")


# 11) Feature list itself must not contain labels or explicitly future-looking fields.
from ml_model import FEATURES
assert not any(str(c).upper().startswith("TARGET") for c in FEATURES)
assert "TARGET_RET" not in FEATURES and "TARGET_UP" not in FEATURES
assert not any("FUTURE" in str(c).upper() for c in FEATURES)
print("PASS no target/future columns in ML features")

# 12) Corporate-event data is currently not part of the model feature set.
# This prevents accidental leakage from ex-post publication/event data.
for forbidden in ["DIVIDEND","DIVIDENDS","CORPORATE","EVENT","REPORT_DATE","PUBLICATION_DATE"]:
    assert forbidden not in {str(c).upper() for c in FEATURES}
print("PASS corporate data isolated from ML features")

# 13) Zero-delay execution is forbidden because signal is generated at Close(t).
try:
    realistic_backtest(bt,execution_delay=0)
    raise AssertionError("execution_delay=0 unexpectedly accepted")
except ValueError:
    pass
print("PASS zero-delay execution blocked")

# 14) Invalid negative costs are rejected rather than creating artificial profit.
for kw in ({"commission":-0.001},{"slippage":-0.001}):
    try:
        realistic_backtest(bt,execution_delay=1,**kw)
        raise AssertionError("negative trading cost unexpectedly accepted")
    except ValueError:
        pass
print("PASS negative costs blocked")

print("ALL DEEP LEAKAGE TESTS PASSED")
