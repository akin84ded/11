import os, json
from pathlib import Path

DATA_DIR = Path(os.getenv("DATA_DIR", "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "stock_forecaster.sqlite3"
STATE_PATH = DATA_DIR / "monitor_state.json"
ALERT_LOG = DATA_DIR / "alerts.csv"

DEFAULT_WATCHLIST = [x.strip().upper() for x in os.getenv(
    "WATCHLIST","SBER,GAZP,LKOH,ROSN,NVTK,TATN,GMKN,MOEX,YDEX,MGNT"
).split(",") if x.strip()][:10]

def env(name, default=""):
    return os.getenv(name, default)

def load_state():
    if not STATE_PATH.exists(): return {}
    try: return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception: return {}

def save_state(state):
    STATE_PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
