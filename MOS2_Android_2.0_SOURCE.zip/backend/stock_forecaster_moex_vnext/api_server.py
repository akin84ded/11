"""Read-only JSON endpoint for Android background signal notifications."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
from config import STATE_PATH

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/health":
            payload={"ok":True}
        elif self.path == "/api/signals":
            try:
                state=json.loads(Path(STATE_PATH).read_text(encoding="utf-8")) if Path(STATE_PATH).exists() else {}
            except Exception:
                state={}
            payload={}
            for ticker, item in state.items():
                if isinstance(item,dict) and item.get("signal") in ("BUY","SELL","HOLD"):
                    payload[str(ticker)]={k:item.get(k) for k in ("signal","price","prob_up","expected_return","score")}
        else:
            self.send_error(404)
            return
        data=json.dumps(payload,ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def log_message(self, fmt, *args):
        return

def serve(host="0.0.0.0",port=8502):
    ThreadingHTTPServer((host,int(port)),Handler).serve_forever()
