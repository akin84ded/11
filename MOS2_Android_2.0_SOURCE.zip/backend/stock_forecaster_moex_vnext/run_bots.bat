@echo off
python bot_service.py
