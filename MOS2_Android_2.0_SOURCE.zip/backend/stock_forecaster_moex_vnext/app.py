import os, time, numpy as np, pandas as pd, streamlit as st, plotly.graph_objects as go
from concurrent.futures import ThreadPoolExecutor,as_completed
from moex import history,marketdata,securities
from analytics import indicators,technical_score,risk,beta
from ml_model import fit_predict,walk_forward,feature_importance
from portfolio import returns_matrix,weights_inverse_vol,portfolio_stats,correlation
from backtest import strategy_backtest,buy_hold,realistic_backtest
from notifications import send_all
from trade_levels import trade_levels
from config import DEFAULT_WATCHLIST,env

st.set_page_config(page_title="мос2",layout="wide")
H=[1,5,10,20,60]
if "watchlist" not in st.session_state:st.session_state.watchlist=DEFAULT_WATCHLIST
if "last_signals" not in st.session_state:st.session_state.last_signals={}
if "alerts" not in st.session_state:st.session_state.alerts=[]

def load(s,years,board,session):
    start=(pd.Timestamp.today()-pd.DateOffset(years=years)).strftime("%Y-%m-%d")
    return history(s,start=start,board=board,session=session)

def row(s,years,h,pu,pdwn):
    df=load(s,years,"TQBR","3"); x=indicators(df); m=fit_predict(x,h)
    sc=technical_score(x); sig="BUY" if m["prob_up"]>=pu and sc>=60 else "SELL" if m["prob_up"]<=pdwn and sc<=40 else "HOLD"
    rr=risk(x)
    return {"Ticker":s,"Price":x.CLOSE.iloc[-1],"Signal":sig,"P(up)":m["prob_up"],
            "Expected":m["expected_return"],"Score":sc,"RSI":x.RSI14.iloc[-1],
            "Vol":rr["annual_vol"],"MaxDD":rr["max_drawdown"]}

st.sidebar.title("⚙️ Настройки")
raw=st.sidebar.text_area("До 10 акций",", ".join(st.session_state.watchlist))
if st.sidebar.button("Применить список"):
    st.session_state.watchlist=list(dict.fromkeys(x.strip().upper() for x in raw.split(",") if x.strip()))[:10]
years=st.sidebar.selectbox("История",[2,5,10],index=1)
h=st.sidebar.selectbox("Горизонт",H,index=3)
pu=st.sidebar.slider("BUY P(up)",.5,.9,.65,.01); pdwn=st.sidebar.slider("SELL P(up)",.1,.5,.35,.01)
refresh=st.sidebar.selectbox("Автообновление",[0,30,60,120,300],index=0)


st.markdown("""
<style>
@media (max-width: 768px) {
  .block-container { padding: 0.7rem 0.65rem 4rem 0.65rem !important; }
  [data-testid="stMetricValue"] { font-size: 1.35rem !important; }
  [data-testid="stTabs"] button { font-size: 0.82rem !important; padding: 0.45rem !important; }
  .stButton > button { width: 100%; min-height: 44px; }
  input, select, textarea { font-size: 16px !important; }
}
</style>
""", unsafe_allow_html=True)

st.title("🇷🇺 Stock Forecaster MOEX")
tabs=st.tabs(["📊 Мониторинг","📈 Подробно","🤖 ML","⚠️ Риск","💼 Портфель","🔄 Backtest","🏢 Корп. события","🎓 Обучение","❓ Помощь","🔎 Сканер MOEX"])

with tabs[0]:
    if st.button("Обновить"): st.cache_data.clear()
    results=[]
    with ThreadPoolExecutor(max_workers=min(10,len(st.session_state.watchlist))) as ex:
        fs={ex.submit(row,s,years,h,pu,pdwn):s for s in st.session_state.watchlist}
        for f in as_completed(fs):
            try:
                z=f.result(); results.append(z)
                old=st.session_state.last_signals.get(z["Ticker"])
                if old and old!=z["Signal"]:
                    st.toast(f"{z['Ticker']}: {old} → {z['Signal']}")
                    st.session_state.alerts.append({"time":str(pd.Timestamp.now()),"ticker":z["Ticker"],"old":old,"new":z["Signal"]})
                st.session_state.last_signals[z["Ticker"]]=z["Signal"]
            except Exception as e: st.warning(f"{fs[f]}: {e}")
    if results:
        st.dataframe(pd.DataFrame(results).sort_values("Ticker"),use_container_width=True)
        st.download_button("CSV",pd.DataFrame(results).to_csv(index=False),"monitor.csv")

with tabs[1]:
    s=st.selectbox("Акция",st.session_state.watchlist)
    df=load(s,years,"TQBR","3"); x=indicators(df)
    fig=go.Figure(); fig.add_trace(go.Candlestick(x=x.index,open=x.OPEN,high=x.HIGH,low=x.LOW,close=x.CLOSE,name=s))
    for c in ["SMA20","SMA50","SMA200"]:
        fig.add_trace(go.Scatter(x=x.index,y=x[c],name=c))
    st.plotly_chart(fig,use_container_width=True)
    st.write("Technical score:",technical_score(x))
    try:
        lv=trade_levels(x)
        st.subheader("Автоматические уровни сделки (оценка по ATR)")
        st.dataframe(pd.DataFrame([lv]).rename(columns={
            "price":"Текущая цена","entry_zone_low":"Покупка от","entry_zone_high":"Покупка до",
            "stop_loss":"Стоп-лосс","take_profit_1":"Цель 1","take_profit_2":"Цель 2",
            "risk_per_share":"Риск на акцию","reward_risk":"Доход/риск","atr":"ATR(14)"
        }),use_container_width=True)
        st.caption("Уровни расчётные, не являются заявками брокеру и не гарантируют исполнение.")
    except Exception as e:
        st.warning(f"Не удалось рассчитать уровни: {e}")

with tabs[2]:
    s=st.selectbox("ML акция",st.session_state.watchlist,key="ml")
    df=indicators(load(s,years,"TQBR","3"))
    for hh in H:
        try:
            m=fit_predict(df,hh); st.write(f"H={hh}: P(up)={m['prob_up']:.1%}, expected={m['expected_return']:.2%}, metrics={m['metrics']}")
        except Exception as e: st.warning(f"H={hh}: {e}")
    try: st.bar_chart(feature_importance(fit_predict(df,h)["clf"]))
    except Exception: pass
    st.subheader("Walk-forward")
    try: st.dataframe(walk_forward(df,h).tail(20),use_container_width=True)
    except Exception as e: st.warning(e)

with tabs[3]:
    s=st.selectbox("Risk акция",st.session_state.watchlist,key="risk")
    st.json(risk(indicators(load(s,years,"TQBR","3"))))

with tabs[4]:
    frames={}
    for s in st.session_state.watchlist:
        try: frames[s]=load(s,years,"TQBR","3")
        except: pass
    ret=returns_matrix(frames)
    if not ret.empty:
        max_w=st.slider("Максимальная доля одной акции",0.10,0.50,0.25,0.05)
        w=weights_inverse_vol(ret,max_weight=max_w)
        capital=st.number_input("Размер портфеля, ₽",min_value=1000.0,value=100000.0,step=10000.0)
        allocation=pd.DataFrame({"Доля":w,"Сумма, ₽":w*capital})
        prices={k:float(v["CLOSE"].dropna().iloc[-1]) for k,v in frames.items()
                if "CLOSE" in v and not v["CLOSE"].dropna().empty}
        allocation["Последняя цена, ₽"]=pd.Series(prices)
        allocation["Оценка количества, шт."]=(allocation["Сумма, ₽"]/allocation["Последняя цена, ₽"]).fillna(0).astype(int)
        st.dataframe(allocation,use_container_width=True)
        st.json(portfolio_stats(ret,w))
        st.caption("Распределение рассчитано по обратной волатильности с ограничением доли. Количество акций округлено вниз; комиссии и лоты брокера не учтены.")
        st.plotly_chart(go.Figure(data=go.Heatmap(z=correlation(ret).values,x=correlation(ret).columns,y=correlation(ret).index)),use_container_width=True)

with tabs[5]:
    s=st.selectbox("Backtest акция",st.session_state.watchlist,key="bt")
    x=indicators(load(s,years,"TQBR","3")).dropna().copy()
    x["SIGNAL"]=((x["CLOSE"]>x["SMA20"]) & (x["RSI14"]>50)).astype(int)
    c1,c2,c3=st.columns(3)
    commission=c1.number_input("Комиссия",0.0,0.02,0.0005,0.0001)
    slippage=c2.number_input("Проскальзывание",0.0,0.02,0.0005,0.0001)
    delay=c3.number_input("Задержка исполнения, дней",1,5,1)
    b=realistic_backtest(x,commission=commission,slippage=slippage,execution_delay=int(delay))
    bh=buy_hold(x,commission=commission,slippage=slippage)
    st.json({k:v for k,v in b.items() if k not in ("equity","returns")})
    st.write("Buy & Hold:",bh["total_return"])
    eq=pd.DataFrame({"Strategy":b["equity"],"Buy & Hold":bh["equity"]}).dropna()
    st.line_chart(eq)
    st.caption("Сигнал формируется на закрытии, исполнение — на следующем открытии; учитываются комиссия и проскальзывание.")

with tabs[6]:
    st.info("Корпоративные события импортируются из CSV: SECID,DATE,TYPE,VALUE.")
    up=st.file_uploader("CSV",type="csv")
    if up is not None:
        st.dataframe(pd.read_csv(up),use_container_width=True)


with tabs[7]:
    st.header("🎓 Обучение: теория торговли и прогнозирования")
    st.info(
        "Практический мини-курс по рынку, техническому анализу, ML-прогнозам, "
        "backtest и управлению риском. Это учебная информация, а не персональная инвестиционная рекомендация."
    )

    st.subheader("1. Как устроен рынок")
    st.markdown("""
Цена формируется спросом и предложением и не является гарантированной «справедливой стоимостью».

- **Open / High / Low / Close** — цены периода;
- **Volume** — объём торгов;
- **Return** — относительное изменение цены.

Прошлая доходность не гарантирует будущую, поэтому любой прогноз — вероятностная оценка.
""")

    st.subheader("2. Технический анализ")
    st.markdown("""
- **SMA / EMA** — сглаживание цены и оценка тренда.
- **RSI (14)** — индикатор импульса; уровни около 70/30 — ориентиры, а не автоматические сигналы.
- **MACD** — оценка изменения импульса.
- **Bollinger Bands** — положение цены относительно волатильности.
- **ATR (14)** — мера диапазона движения и риска.
- **OBV / Volume** — связь цены и торговой активности.
""")

    st.subheader("3. Как читать ML-прогноз")
    st.markdown("""
**P(up)** — вероятность положительной доходности на выбранном горизонте.

**Expected return** — оценка будущей доходности.

`P(up)=0.62` не означает рост цены на 62%. Это оценка вероятности положительного результата
согласно модели. Смотрите одновременно на вероятность, ожидаемую доходность, волатильность,
размер позиции и торговые издержки.
""")

    st.subheader("4. Look-ahead bias")
    st.warning("Нельзя использовать информацию, которая в момент принятия решения ещё не была известна.")
    st.markdown("""
Если сигнал рассчитан после **Close(t)**, реалистичная последовательность:

**Close(t) → сигнал → Open(t+1) → исполнение.**

Look-ahead возникает при случайном перемешивании временного ряда, использовании будущих
значений признаков, подготовке данных с доступом ко всему датасету или применении информации,
опубликованной позже момента сделки.
""")

    st.subheader("5. Walk-forward")
    st.markdown("""
**Walk-forward**: прошлое → обучение → следующий тестовый участок → расширение обучения → следующий тест.

Для финансовых временных рядов это обычно честнее случайного train/test split, потому что
сохраняется порядок времени.
""")

    st.subheader("6. Управление риском")
    st.markdown("""
- **Max Drawdown** — максимальная просадка от предыдущего пика.
- **Annual Volatility** — годовая оценка волатильности.
- **VaR / CVaR** — оценки неблагоприятных хвостовых сценариев.
- **Position size** — размер позиции.
- **Correlation** — совместное движение активов.

Даже 10 акций могут быть слабо диверсифицированы при высокой корреляции.
""")

    st.subheader("7. Как строить торговый сигнал")
    st.markdown("""
Практичная схема:

**ML-прогноз + техническое подтверждение + риск-контроль + стоимость исполнения.**

ML оценивает `P(up)` и `Expected return`, технический блок проверяет тренд и импульс,
риск-блок ограничивает позицию, а backtest учитывает комиссии и slippage.
""")

    st.subheader("8. Тонкости прогнозирования")
    st.markdown("""
- Горизонт 1 день и 60 дней — разные задачи.
- Рыночный режим меняется.
- Доходности и относительные признаки часто устойчивее абсолютного уровня цены.
- Каждый признак должен быть доступен в момент прогноза.
- Больше признаков не означает автоматически лучшую модель.
- ML нужно сравнивать с buy-and-hold и другими baseline.
""")

    st.subheader("9. Как оценивать backtest")
    st.markdown("""
Проверяйте не только итоговую прибыль, но и:

- **Total Return**;
- **Annual Return**;
- **Annual Volatility**;
- **Max Drawdown**;
- **Sharpe**;
- число сделок;
- комиссии;
- slippage;
- execution delay.

Если стратегия прибыльна только без издержек или при идеальном исполнении, результат следует
считать подозрительным.
""")

    st.subheader("10. Типичные ошибки новичка")
    st.markdown("""
1. Покупать только потому, что RSI ниже 30.
2. Считать `P(up)=0.70` гарантией роста.
3. Игнорировать Max Drawdown.
4. Использовать слишком большую позицию.
5. Не учитывать комиссии и slippage.
6. Перемешивать временные данные.
7. Подгонять параметры под один исторический период.
8. Считать backtest доказательством будущей прибыли.
9. Игнорировать ликвидность.
10. Не проверять, была ли информация доступна в момент сигнала.
""")

    st.subheader("11. Практический алгоритм")
    st.markdown("""
**1.** Выбрать ликвидные бумаги.  
**2.** Проверить исторические данные.  
**3.** Оценить тренд, объём и волатильность.  
**4.** Обучить модель только на прошлом.  
**5.** Выполнить walk-forward.  
**6.** Провести реалистичный backtest.  
**7.** Учесть комиссии и slippage.  
**8.** Ограничить размер позиции.  
**9.** Сравнить с buy-and-hold и benchmark.  
**10.** Перед реальными деньгами использовать наблюдение или бумажную торговлю.
""")


    st.subheader("13. Теория анализа акций")
    st.markdown("""
Анализ акции удобно разделять на несколько уровней. Они отвечают на разные вопросы и лучше
работают вместе, чем по отдельности.

### Фундаментальный анализ
Фундаментальный анализ пытается понять качество бизнеса и соотношение цены акции с его
экономическими результатами.

На что обычно смотрят:
- **Выручка** — растёт ли масштаб бизнеса;
- **Чистая прибыль** — зарабатывает ли компания после расходов;
- **Маржинальность** — насколько эффективно выручка превращается в прибыль;
- **Денежный поток** — подкрепляется ли бухгалтерская прибыль реальными деньгами;
- **Долг** — насколько компания зависит от заёмного капитала;
- **ROE / ROA / ROIC** — эффективность использования капитала и активов;
- **P/E, P/B, EV/EBITDA** — относительная оценка компании рынком;
- **Дивиденды** — размер, устойчивость и источник выплат.

Низкий P/E сам по себе не означает, что акция дешёвая: рынок может ожидать падения прибыли.
Высокий P/E также не обязательно означает переоценку, если прибыль быстро растёт.

### Технический анализ
Технический анализ изучает прежде всего цену, объём, тренд, импульс и волатильность.

Полезная последовательность:
1. определить долгосрочный тренд;
2. посмотреть положение цены относительно SMA/EMA;
3. оценить импульс через RSI/MACD;
4. проверить волатильность через ATR/Bollinger Bands;
5. посмотреть, подтверждается ли движение объёмом;
6. только после этого формировать гипотезу.

Индикаторы рассчитываются из одних и тех же рыночных данных, поэтому несколько индикаторов
не всегда являются независимыми подтверждениями.
""")

    st.subheader("14. Анализ тренда")
    st.markdown("""
Тренд — устойчивое направление движения цены.

Упрощённо:
- последовательность повышающихся максимумов и минимумов — **восходящий тренд**;
- понижающихся максимумов и минимумов — **нисходящий тренд**;
- отсутствие выраженного направления — **боковой рынок**.

Скользящие средние помогают формализовать наблюдение. Например, цена выше SMA200 и
SMA50 выше SMA200 могут указывать на долгосрочно положительную структуру, но это не
гарантирует продолжение роста.

Важно различать **тренд** и **моментум**: тренд описывает направление структуры рынка,
а моментум — скорость и силу текущего движения.
""")

    st.subheader("15. Поддержка, сопротивление и пробой")
    st.markdown("""
**Поддержка** — область, где ранее усиливался спрос.  
**Сопротивление** — область, где ранее усиливалось предложение.

Это скорее зоны, чем точные цены. Чем очевиднее уровень, тем больше участников может за ним
наблюдать.

Пробой уровня полезно оценивать вместе с:
- объёмом;
- волатильностью;
- ценой закрытия;
- общим трендом;
- последующим удержанием уровня.

Короткий выход за уровень и быстрый возврат называется ложным пробоем. Поэтому реакция после
пробоя иногда информативнее самого пересечения линии.
""")

    st.subheader("16. Анализ объёма и ликвидности")
    st.markdown("""
Объём показывает активность, но не говорит напрямую, кто «победил»: у каждой сделки есть
покупатель и продавец.

Рост цены на повышенном объёме иногда рассматривают как более сильное подтверждение движения,
чем рост при слабой активности.

**Ликвидность** особенно важна для реальной стратегии. При низкой ликвидности:
- spread может быть шире;
- slippage выше;
- крупный приказ способен повлиять на цену;
- исторический backtest может переоценивать возможность исполнения.

Поэтому сигнал без оценки ликвидности ещё не является готовой торговой стратегией.
""")

    st.subheader("17. Анализ волатильности")
    st.markdown("""
Волатильность описывает масштаб колебаний, а не направление цены.

Высокая волатильность означает более широкий диапазон возможных результатов. Это влияет на:
- размер позиции;
- допустимый риск;
- расстояние до защитных уровней;
- доверительный диапазон прогноза;
- величину возможного slippage.

ATR измеряет диапазон движения в ценовых единицах, а стандартное отклонение доходностей
позволяет оценивать статистическую волатильность. Сравнивая разные акции, полезнее использовать
относительные или нормализованные показатели.
""")

    st.subheader("18. Факторный и сравнительный анализ")
    st.markdown("""
Цена отдельной акции зависит не только от самой компании. Полезно сравнивать её с:
- индексом рынка;
- отраслевым индексом;
- похожими компаниями;
- процентными ставками;
- валютой и сырьём, если бизнес от них зависит.

**Beta** показывает чувствительность доходности акции к движениям выбранного benchmark.
Beta выше 1 исторически означает более сильную реакцию на движения benchmark, но показатель
может меняться со временем.

**Relative strength** помогает увидеть, растёт ли акция быстрее рынка или отстаёт от него.
Акция может падать в абсолютном выражении, но одновременно быть сильнее падающего рынка.
""")

    st.subheader("19. Анализ доходности и риска")
    st.markdown("""
Одна только средняя доходность мало что говорит о качестве стратегии.

Нужно анализировать распределение результатов:
- среднюю и медианную доходность;
- стандартное отклонение;
- отрицательные периоды;
- Max Drawdown;
- VaR/CVaR;
- Sharpe;
- длительность просадок.

Две стратегии с одинаковой итоговой прибылью могут иметь совершенно разный риск. Стратегия
с меньшей просадкой и более стабильной динамикой иногда практичнее стратегии с максимальной
исторической доходностью.
""")

    st.subheader("20. Мульти-таймфрейм анализ")
    st.markdown("""
Один и тот же актив может одновременно находиться в долгосрочном восходящем тренде и
краткосрочной коррекции.

Поэтому полезно разделять:
- **долгосрочный контекст** — основной тренд;
- **среднесрочную структуру** — текущая фаза движения;
- **короткий горизонт** — точка входа и локальный риск.

Горизонт индикаторов должен соответствовать горизонту прогноза. Использовать краткосрочный
сигнал для долгосрочного решения без дополнительного анализа обычно недостаточно.
""")

    st.subheader("21. Как объединять виды анализа")
    st.markdown("""
Пример последовательного анализа акции:

**1. Контекст:** что происходит с рынком и отраслью?  
**2. Фундаментал:** устойчивы ли бизнес, прибыль, денежный поток и долг?  
**3. Оценка:** насколько текущая цена соответствует показателям компании и аналогам?  
**4. Тренд:** в каком направлении движется цена?  
**5. Моментум:** ускоряется или ослабевает движение?  
**6. Волатильность:** насколько велик обычный диапазон колебаний?  
**7. Объём и ликвидность:** можно ли реалистично исполнить сделку?  
**8. ML:** есть ли статистическое преимущество на выбранном горизонте?  
**9. Риск:** сколько капитала допустимо поставить под эту гипотезу?  
**10. Проверка:** выдерживает ли идея walk-forward и реалистичный backtest?

Смысл комплексного анализа не в том, чтобы получить десять одинаковых сигналов «покупать».
Его задача — проверить гипотезу с разных сторон и понять, **почему она может оказаться неверной**.
""")

    st.subheader("22. Аналитическая дисциплина")
    st.markdown("""
Перед решением полезно заранее записать:

- **гипотезу** — почему ожидается движение;
- **горизонт** — когда гипотеза должна проявиться;
- **условие подтверждения**;
- **условие отмены гипотезы**;
- **допустимый риск**;
- **benchmark**, с которым сравнивается результат.

Это уменьшает риск подгонки объяснения уже после движения цены. Хороший анализ допускает
ошибку и заранее определяет, какие данные покажут, что исходная идея была неверной.
""")

    st.subheader("23. Мини-шпаргалка")
    cheat = {
        "P(up)": "вероятность положительной доходности",
        "Expected return": "оценка будущей доходности",
        "RSI": "индикатор импульса",
        "ATR": "оценка волатильности диапазона",
        "Max Drawdown": "максимальная просадка",
        "Walk-forward": "проверка модели по времени",
        "Look-ahead": "утечка информации из будущего",
        "Slippage": "разница между ожидаемой и фактической ценой",
        "Sharpe": "доходность относительно риска",
        "Buy & Hold": "базовая стратегия для сравнения",
    }
    st.table(pd.DataFrame(list(cheat.items()), columns=["Термин", "Значение"]))

with tabs[8]:
    st.markdown("""### Что делает программа
MOEX ISS → очистка → индикаторы → ML → сигнал → риск → мониторинг.

### График
Свечи + SMA20/50/200.

### ML
P(up) — вероятность роста на выбранном горизонте. Expected — ожидаемая доходность модели. Metrics считаются на временном holdout.

### Backtest
Комиссия и проскальзывание учитываются. Сигнал исполняется со следующего дня.

### Портфель
Inverse-volatility распределяет вес обратно пропорционально исторической волатильности, с ограничением веса.

### Telegram/MAX
Уведомления работают через API. Для команд используется Long Polling — webhook не нужен.

### Важно
Это исследовательская система, а не гарантия прибыли. Проверяйте ликвидность, новости, корпоративные события и ограничения API.
""")

if refresh:
    time.sleep(refresh); st.rerun()


with tabs[9]:
    st.header("Сканер всех акций MOEX")
    st.caption("Сканирование бумаг основного рынка акций TQBR. Запросы идут к MOEX ISS; объём данных и время зависят от доступности сервера.")
    scan_years=st.selectbox("Глубина истории сканера",[1,2,3],index=0)
    scan_ml=st.checkbox("Добавить ML-прогноз (медленнее)",value=False)
    if st.button("Запустить полный сканер MOEX",type="primary"):
        try:
            universe=securities(board="TQBR")
            if universe.empty or "SECID" not in universe:
                st.error("MOEX ISS не вернул список бумаг.")
            else:
                names={}
                if "SHORTNAME" in universe:
                    names=dict(zip(universe["SECID"].astype(str),universe["SHORTNAME"].fillna("").astype(str)))
                symbols=universe["SECID"].dropna().astype(str).drop_duplicates().tolist()
                # Remove non-equity technical instruments when ISS provides a security type.
                if "TYPE" in universe:
                    allowed=universe[universe["TYPE"].astype(str).str.lower().isin(["common_share","preferred_share","1","2"])]
                    if not allowed.empty: symbols=allowed["SECID"].dropna().astype(str).drop_duplicates().tolist()
                st.write(f"Найдено бумаг на TQBR: **{len(symbols)}**")
                start=(pd.Timestamp.today()-pd.DateOffset(years=scan_years)).strftime("%Y-%m-%d")
                progress=st.progress(0.0)
                status=st.empty()
                rows=[]
                def scan_one(secid):
                    hist=history(secid,start=start,board="TQBR",session="3")
                    if hist.empty or "CLOSE" not in hist or len(hist)<80:
                        return None
                    x=indicators(hist.dropna(subset=["CLOSE"]))
                    if x.empty or x["CLOSE"].dropna().empty:
                        return None
                    score=float(technical_score(x))
                    lv=trade_levels(x)
                    sig="BUY" if score>=60 else "SELL" if score<=40 else "HOLD"
                    item={"Тикер":secid,"Компания":names.get(secid,""),"Цена":lv["price"],
                          "Сигнал":sig,"Тех. оценка":score,
                          "Покупка от":lv["entry_zone_low"],"Покупка до":lv["entry_zone_high"],
                          "Стоп":lv["stop_loss"],"Цель":lv["take_profit_2"],
                          "ATR":lv["atr"]}
                    if scan_ml:
                        try:
                            model=fit_predict(x,20)
                            item["P(рост)"]=model["prob_up"]
                            item["Ожид. доходность"]=model["expected_return"]
                        except Exception:
                            item["P(рост)"]=np.nan
                            item["Ожид. доходность"]=np.nan
                    return item
                from concurrent.futures import ThreadPoolExecutor,as_completed
                completed=0
                with ThreadPoolExecutor(max_workers=8) as pool:
                    futures={pool.submit(scan_one,sym):sym for sym in symbols}
                    for fut in as_completed(futures):
                        completed+=1
                        try:
                            item=fut.result()
                            if item: rows.append(item)
                        except Exception:
                            pass
                        if completed%5==0 or completed==len(futures):
                            progress.progress(completed/max(1,len(futures)))
                            status.write(f"Обработано {completed}/{len(futures)}; успешно: {len(rows)}")
                if rows:
                    result=pd.DataFrame(rows)
                    order={"BUY":0,"HOLD":1,"SELL":2}
                    result["_sort"]=result["Сигнал"].map(order)
                    result=result.sort_values(["_sort","Тех. оценка"],ascending=[True,False]).drop(columns="_sort")
                    st.dataframe(result,use_container_width=True)
                    st.download_button("Скачать результаты сканера CSV",
                        result.to_csv(index=False).encode("utf-8-sig"),
                        file_name="mos2_moex_scan.csv",mime="text/csv")
                    st.success(f"Сканирование завершено: {len(rows)} бумаг с достаточной историей.")
                else:
                    st.warning("Нет бумаг с достаточной историей для расчёта.")
        except Exception as e:
            st.error(f"Сканер не смог получить данные MOEX: {e}")
