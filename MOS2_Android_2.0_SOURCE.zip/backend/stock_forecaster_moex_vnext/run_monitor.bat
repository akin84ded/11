@echo off
python monitor_service.py
