import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingRegressor
from sklearn.metrics import accuracy_score, roc_auc_score, precision_score, recall_score, mean_absolute_error

FEATURES=["RET_1","RET_5","SMA20","SMA50","SMA200","EMA20","RSI14","MACD",
          "MACD_SIGNAL","BB_UP","BB_DN","ATR14","VOL_Z","VOL_ANN"]

def dataset(df,horizon):
    horizon=int(horizon)
    if horizon < 1:
        raise ValueError("horizon must be >= 1")
    x=df.copy()
    x["TARGET_RET"]=x["CLOSE"].shift(-horizon)/x["CLOSE"]-1
    x["TARGET_UP"]=(x["TARGET_RET"]>0).astype(int)
    return x.dropna(subset=FEATURES+["TARGET_RET"])

def _purged_split(d, cut, horizon):
    """
    Purged temporal split.
    Training labels use CLOSE[t+horizon], therefore the final `horizon`
    candidate rows before the test boundary are excluded from training.
    """
    cut=int(cut); horizon=int(horizon)
    if cut <= horizon:
        return d.iloc[:0], d.iloc[cut:]
    return d.iloc[:cut-horizon], d.iloc[cut:]

def fit_predict(df,horizon=20,test_size=.2,random_state=42):
    d=dataset(df,horizon)
    if len(d)<150:
        raise ValueError("Недостаточно данных для ML")
    cut=int(len(d)*(1-test_size))
    tr,te=_purged_split(d,cut,horizon)
    if len(tr)<100 or te.empty:
        raise ValueError("Недостаточно данных после purged split")

    clf=RandomForestClassifier(n_estimators=300,min_samples_leaf=5,
        class_weight="balanced",random_state=random_state,n_jobs=-1)
    reg=HistGradientBoostingRegressor(max_iter=250,l2_regularization=1.0,
        random_state=random_state)
    clf.fit(tr[FEATURES],tr.TARGET_UP)
    reg.fit(tr[FEATURES],tr.TARGET_RET)

    p=clf.predict_proba(te[FEATURES])[:,1]
    y=te.TARGET_UP
    pred=reg.predict(te[FEATURES])
    metrics={
      "accuracy":accuracy_score(y,p>=.5),
      "auc":roc_auc_score(y,p) if y.nunique()>1 else np.nan,
      "precision":precision_score(y,p>=.5,zero_division=0),
      "recall":recall_score(y,p>=.5,zero_division=0),
      "mae":mean_absolute_error(te.TARGET_RET,pred),
      "test_rows":len(te),
      "train_rows":len(tr),
      "purge_rows":horizon
    }

    # Latest row has no target requirement: this is the current forward prediction.
    last=df.dropna(subset=FEATURES).iloc[-1:]
    return {
        "clf":clf,"reg":reg,
        "prob_up":float(clf.predict_proba(last[FEATURES])[:,1][0]),
        "expected_return":float(reg.predict(last[FEATURES])[0]),
        "metrics":metrics,"features":FEATURES
    }

def walk_forward(df,horizon=20,min_train=200,step=20):
    horizon=int(horizon)
    d=dataset(df,horizon)
    rows=[]
    if len(d)<=min_train+horizon:
        return pd.DataFrame()

    # end = first row of test fold. Purge horizon rows before it.
    for end in range(min_train+horizon,len(d),step):
        te=d.iloc[end:min(end+step,len(d))]
        if te.empty:
            break
        tr=d.iloc[:end-horizon]
        if len(tr)<min_train:
            continue

        clf=RandomForestClassifier(n_estimators=150,min_samples_leaf=5,
             class_weight="balanced",random_state=42,n_jobs=-1)
        reg=HistGradientBoostingRegressor(max_iter=150,l2_regularization=1.0,random_state=42)
        clf.fit(tr[FEATURES],tr.TARGET_UP)
        reg.fit(tr[FEATURES],tr.TARGET_RET)
        p=clf.predict_proba(te[FEATURES])[:,1]

        rows.append({
            "end":te.index[-1],
            "train_end":tr.index[-1],
            "test_start":te.index[0],
            "purge_rows":horizon,
            "accuracy":accuracy_score(te.TARGET_UP,p>=.5),
            "auc":roc_auc_score(te.TARGET_UP,p) if te.TARGET_UP.nunique()>1 else np.nan,
            "mae":mean_absolute_error(te.TARGET_RET,reg.predict(te[FEATURES]))
        })
    return pd.DataFrame(rows)

def feature_importance(model):
    if not hasattr(model,"feature_importances_"):
        return pd.Series(dtype=float)
    return pd.Series(model.feature_importances_,index=FEATURES).sort_values(ascending=False)
