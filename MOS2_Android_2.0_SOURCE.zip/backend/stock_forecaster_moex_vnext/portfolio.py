import numpy as np, pandas as pd

def returns_matrix(frames):
    cols={}
    for k,df in frames.items():
        if "CLOSE" in df: cols[k]=df["CLOSE"].pct_change()
    return pd.DataFrame(cols).dropna(how="all")

def weights_inverse_vol(returns,max_weight=.25,min_weight=0.0):
    """Inverse-volatility allocation with a hard per-name cap."""
    if returns is None or returns.empty:
        return pd.Series(dtype=float)
    vol=returns.std()*np.sqrt(252)
    inv=(1/vol.replace(0,np.nan)).replace([np.inf,-np.inf],np.nan).dropna()
    if inv.empty: return pd.Series(0.0,index=returns.columns)
    n=len(inv)
    cap=float(max_weight)
    if cap<=0: raise ValueError("max_weight must be positive")
    cap=max(cap,1.0/n)
    raw=inv/inv.sum()
    weights=pd.Series(0.0,index=returns.columns,dtype=float)
    active=list(raw.index)
    remaining=1.0
    while active:
        denom=float(raw.loc[active].sum())
        if denom<=0: break
        proposed=raw.loc[active]/denom*remaining
        over=proposed[proposed>cap+1e-12].index.tolist()
        if not over:
            weights.loc[active]=proposed
            break
        for name in over:
            weights[name]=cap
            remaining-=cap
            active.remove(name)
        if remaining<=1e-12: break
    if weights.sum()>0: weights/=weights.sum()
    return weights


def portfolio_stats(returns,weights):
    r=returns.fillna(0).dot(weights.reindex(returns.columns).fillna(0))
    return {"annual_return":float(r.mean()*252),
            "annual_vol":float(r.std()*np.sqrt(252)),
            "sharpe":float(r.mean()/r.std()*np.sqrt(252)) if r.std()>0 else 0,
            "max_drawdown":float(((1+r).cumprod()/(1+r).cumprod().cummax()-1).min())}

def correlation(returns): return returns.corr()
