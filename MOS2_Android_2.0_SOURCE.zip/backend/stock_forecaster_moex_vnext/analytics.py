import numpy as np, pandas as pd

def indicators(df):
    x=df.copy()
    c=x["CLOSE"].astype(float)
    v=x["VOLUME"].astype(float) if "VOLUME" in x else pd.Series(index=x.index,dtype=float)
    x["RET_1"]=c.pct_change()
    x["RET_5"]=c.pct_change(5)
    x["SMA20"]=c.rolling(20).mean()
    x["SMA50"]=c.rolling(50).mean()
    x["SMA200"]=c.rolling(200).mean()
    x["EMA20"]=c.ewm(span=20,adjust=False).mean()
    delta=c.diff(); gain=delta.clip(lower=0); loss=-delta.clip(upper=0)
    rs=gain.rolling(14).mean()/loss.rolling(14).mean().replace(0,np.nan)
    x["RSI14"]=100-(100/(1+rs))
    ema12=c.ewm(span=12,adjust=False).mean(); ema26=c.ewm(span=26,adjust=False).mean()
    x["MACD"]=ema12-ema26; x["MACD_SIGNAL"]=x["MACD"].ewm(span=9,adjust=False).mean()
    mid=c.rolling(20).mean(); sd=c.rolling(20).std()
    x["BB_UP"]=mid+2*sd; x["BB_DN"]=mid-2*sd
    tr=pd.concat([(x["HIGH"]-x["LOW"]),
                  (x["HIGH"]-c.shift()).abs(),
                  (x["LOW"]-c.shift()).abs()],axis=1).max(axis=1)
    x["ATR14"]=tr.rolling(14).mean()
    obv=(np.sign(c.diff()).fillna(0)*v.fillna(0)).cumsum()
    x["OBV"]=obv
    x["VOL_Z"]=(v-v.rolling(30).mean())/v.rolling(30).std()
    x["VOL_ANN"]=x["RET_1"].rolling(252).std()*np.sqrt(252)
    return x

def risk(df):
    r=df["CLOSE"].pct_change().dropna()
    if r.empty: return {}
    wealth=(1+r).cumprod()
    dd=wealth/wealth.cummax()-1
    var=float(r.quantile(.05))
    tail=r[r<=var]
    return {
        "annual_vol":float(r.std()*np.sqrt(252)),
        "VaR_95":var,
        "CVaR_95":float(tail.mean()) if len(tail) else var,
        "max_drawdown":float(dd.min()),
        "total_return":float(wealth.iloc[-1]-1),
        "observations":int(len(r))
    }

def beta(asset, benchmark):
    a=asset["CLOSE"].pct_change(); b=benchmark["CLOSE"].pct_change()
    z=pd.concat([a,b],axis=1).dropna()
    if len(z)<30 or z.iloc[:,1].var()==0:return np.nan
    return float(z.iloc[:,0].cov(z.iloc[:,1])/z.iloc[:,1].var())

def technical_score(x):
    if x.empty:return 0.0
    z=x.iloc[-1]; s=0
    for cond,pts in [
        (z.get("CLOSE",np.nan)>z.get("SMA20",np.nan),1),
        (z.get("SMA20",np.nan)>z.get("SMA50",np.nan),1),
        (z.get("RSI14",50)>50,1),
        (z.get("MACD",0)>z.get("MACD_SIGNAL",0),1),
        (z.get("VOL_Z",0)>0,0.5)]:
        if bool(cond):s+=pts
    return round(100*s/4.5,1)
