import os,time,pandas as pd
from config import DEFAULT_WATCHLIST,load_state,save_state,env
from moex import history
from analytics import indicators,technical_score,risk
from ml_model import fit_predict
from notifications import send_all

def evaluate(secid):
    df=history(secid,board=env("MOEX_BOARD","TQBR"),session=env("MOEX_SESSION","3"))
    x=indicators(df.dropna(subset=["CLOSE"]))
    m=fit_predict(x,20)
    sig="BUY" if m["prob_up"]>=.65 and technical_score(x)>=60 else "SELL" if m["prob_up"]<=.35 and technical_score(x)<=40 else "HOLD"
    return {"secid":secid,"signal":sig,"prob_up":m["prob_up"],
            "expected_return":m["expected_return"],"score":technical_score(x),
            "price":float(x.CLOSE.iloc[-1]),"risk":risk(x)}

def main():
    interval=int(env("MONITOR_INTERVAL","300"))
    state=load_state()
    tg=(env("TELEGRAM_BOT_TOKEN"),env("TELEGRAM_CHAT_ID"))
    mx=(env("MAX_BOT_TOKEN"),env("MAX_CHAT_ID"))
    tg=tg if all(tg) else None; mx=mx if all(mx) else None
    while True:
        for s in DEFAULT_WATCHLIST:
            try:
                z=evaluate(s); old=state.get(s,{}).get("signal")
                if old and old!=z["signal"]:
                    text=f"📊 {s}: {old} → {z['signal']}\\nЦена: {z['price']:.2f}\\nP(up): {z['prob_up']:.1%}\\nScore: {z['score']:.1f}\\nОжид. доходность: {z['expected_return']:.2%}"
                    send_all(text,tg,mx)
                state[s]=z; save_state(state)
            except Exception as e:
                state[s]={"error":str(e)}; save_state(state)
        time.sleep(interval)

if __name__=="__main__": main()
