import pandas as pd
from pathlib import Path

def load_corporate_csv(path):
    p=Path(path)
    if not p.exists(): return pd.DataFrame()
    df=pd.read_csv(p)
    # Expected optional columns: SECID, DATE, TYPE, VALUE
    return df

def dividends_for(df, secid=None):
    if df.empty:return df
    x=df.copy()
    if secid and "SECID" in x:x=x[x.SECID.astype(str).str.upper().eq(secid.upper())]
    if "TYPE" in x:x=x[x.TYPE.astype(str).str.lower().str.contains("div")]
    return x
