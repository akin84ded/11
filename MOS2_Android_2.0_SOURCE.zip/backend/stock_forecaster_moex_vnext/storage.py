import sqlite3, pandas as pd, json, time
from config import DB_PATH

def init_db():
    with sqlite3.connect(DB_PATH) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS history(
          secid TEXT, tradedate TEXT, payload TEXT,
          PRIMARY KEY(secid,tradedate))""")
        c.execute("""CREATE TABLE IF NOT EXISTS kv(
          key TEXT PRIMARY KEY, value TEXT, updated REAL)""")

def cache_history(secid,df):
    init_db()
    with sqlite3.connect(DB_PATH) as c:
        for idx,row in df.iterrows():
            c.execute("INSERT OR REPLACE INTO history VALUES(?,?,?)",
                      (secid,str(idx.date()),row.to_json()))
def get_cached(secid):
    init_db()
    with sqlite3.connect(DB_PATH) as c:
        rows=c.execute("SELECT tradedate,payload FROM history WHERE secid=? ORDER BY tradedate",
                       (secid,)).fetchall()
    if not rows:return pd.DataFrame()
    data=[]
    for d,p in rows:
        z=json.loads(p); z["TRADEDATE"]=pd.to_datetime(d); data.append(z)
    x=pd.DataFrame(data).set_index("TRADEDATE")
    return x

def set_kv(k,v):
    init_db()
    with sqlite3.connect(DB_PATH) as c:
        c.execute("INSERT OR REPLACE INTO kv VALUES(?,?,?)",(k,json.dumps(v,ensure_ascii=False),time.time()))
def get_kv(k,default=None):
    init_db()
    with sqlite3.connect(DB_PATH) as c:
        r=c.execute("SELECT value FROM kv WHERE key=?",(k,)).fetchone()
    return default if not r else json.loads(r[0])
