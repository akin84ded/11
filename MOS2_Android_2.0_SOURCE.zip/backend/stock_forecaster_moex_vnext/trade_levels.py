"""Rule-based, volatility-aware trade levels. Not investment advice."""
import numpy as np

def trade_levels(frame, atr_multiple_stop=2.0, atr_multiple_target=3.0):
    if frame is None or frame.empty or "CLOSE" not in frame:
        raise ValueError("Нет ценовых данных для расчёта уровней")
    close=float(frame["CLOSE"].iloc[-1])
    atr=float(frame["ATR14"].iloc[-1]) if "ATR14" in frame else float("nan")
    if not np.isfinite(close) or close<=0:
        raise ValueError("Некорректная последняя цена")
    if not np.isfinite(atr) or atr<=0:
        recent=frame["CLOSE"].pct_change().dropna().tail(20)
        atr=close*float(recent.std()) if len(recent)>2 else close*0.02
    atr=max(float(atr), close*0.002)
    return {
        "price": close,
        "entry_zone_low": max(0.0, close-0.5*atr),
        "entry_zone_high": close+0.25*atr,
        "stop_loss": max(0.0, close-atr_multiple_stop*atr),
        "take_profit_1": close+2.0*atr,
        "take_profit_2": close+atr_multiple_target*atr,
        "risk_per_share": atr_multiple_stop*atr,
        "reward_risk": atr_multiple_target/atr_multiple_stop,
        "atr": atr,
    }
