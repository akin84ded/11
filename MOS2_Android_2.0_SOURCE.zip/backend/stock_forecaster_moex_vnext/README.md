# Stock Forecaster MOEX — Complete

Исследовательский терминал для акций MOEX (TQBR), до 10 бумаг.

## Возможности
- MOEX ISS: история, текущие котировки, candles.
- ML-прогноз 1/5/10/20/60 торговых дней.
- Walk-forward backtest без look-ahead.
- Реалистичный backtest с комиссией и проскальзыванием.
- Сравнение с IMOEX при наличии данных.
- Технические индикаторы и скоринг.
- Риск: volatility, VaR, CVaR, Max Drawdown, beta.
- Портфель 10 акций: equal-weight и inverse-volatility веса, ограничения на вес.
- Дивидендные/корпоративные данные через локальный CSV-импорт.
- SQLite-кэш истории и состояния мониторинга.
- Фоновый мониторинг без Streamlit.
- Telegram и MAX через Long Polling, без webhook.
- Команды бота: /start /help /ping /status /signals /add /remove /portfolio.
- Алерты по сигналам, вероятности, score, цене и объёму.
- CSV-экспорт.
- Подробная вкладка помощи.

## Запуск
pip install -r requirements.txt
streamlit run app.py

Фоновый монитор:
python monitor_service.py

Бот:
python bot_service.py

Тесты:
python tests_complete.py

Токены не храните в коде. Используйте переменные окружения.


## MOS2 2.0 additions
- Full TQBR securities scanner (`securities()` pagination in MOEX ISS).
- ATR-based entry zone, stop-loss and two profit targets (`trade_levels.py`).
- Inverse-volatility portfolio with a hard per-security concentration cap.
- Read-only Android signal endpoint on port 8502 (`/api/signals`), started with `run_mobile_server.py`.
- Run `python tests_mos2_full.py` for 2.0 regression checks.

Android background notifications poll this endpoint approximately every 15 minutes. Run `run_monitor.bat` separately to refresh signal state. For public HTTPS deployment, reverse-proxy `/api/signals` to port 8502.
