import pandas as pd
import numpy as np
from analytics import beta

def compare(asset, benchmark, asset_bt=None, benchmark_bt=None):
    a=asset["CLOSE"].pct_change().dropna()
    b=benchmark["CLOSE"].pct_change().dropna()
    z=pd.concat([a,b],axis=1,join="inner").dropna()
    if z.empty:return {}
    ar=(1+z.iloc[:,0]).prod()-1
    br=(1+z.iloc[:,1]).prod()-1
    tracking=(z.iloc[:,0]-z.iloc[:,1]).std()*np.sqrt(252)
    active=z.iloc[:,0]-z.iloc[:,1]
    return {
      "asset_return":float(ar),"benchmark_return":float(br),
      "excess_return":float(ar-br),
      "tracking_error":float(tracking),
      "information_ratio":float(active.mean()/active.std()*np.sqrt(252)) if active.std()>0 else 0,
      "beta":float(beta(asset,benchmark))
    }

def walk_forward_summary(wf):
    if wf is None or wf.empty:return {}
    return {c:float(wf[c].mean()) for c in ["accuracy","auc","mae"] if c in wf}
