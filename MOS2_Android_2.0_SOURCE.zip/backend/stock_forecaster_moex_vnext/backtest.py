import numpy as np, pandas as pd

def realistic_backtest(
    df,
    signal_col="SIGNAL",
    commission=0.0005,
    slippage=0.0005,
    execution_delay=1,
    max_position=1.0,
    initial_cash=1_000_000,
):
    """
    Long-only daily backtest.
    - signal generated at close t
    - order executed at OPEN t+execution_delay
    - optional gap handling through actual open
    - commission + slippage
    - position capped at max_position
    - equity marked to close
    """
    execution_delay=int(execution_delay)
    if execution_delay < 1:
        raise ValueError("execution_delay must be >= 1 for close-generated signals")
    if commission < 0 or slippage < 0:
        raise ValueError("commission and slippage must be >= 0")
    if not (0 <= max_position <= 1):
        raise ValueError("max_position must be between 0 and 1")

    x=df.copy().sort_index()
    required={"OPEN","HIGH","LOW","CLOSE",signal_col}
    missing=required-set(x.columns)
    if missing: raise ValueError(f"Missing columns: {sorted(missing)}")
    sig=x[signal_col].astype(float).clip(0,max_position)
    target=sig.shift(execution_delay).fillna(0)

    cash=float(initial_cash)
    shares=0.0
    rows=[]
    trades=0
    total_cost=0.0

    for i,(idx,row) in enumerate(x.iterrows()):
        open_px=float(row["OPEN"]); close_px=float(row["CLOSE"])
        target_value=float(initial_cash)*float(target.iloc[i])
        equity_pre=cash+shares*open_px

        desired_shares=max(0.0,target_value/open_px)
        delta=desired_shares-shares

        if abs(delta)>1e-12:
            side=1 if delta>0 else -1
            exec_px=open_px*(1+side*slippage)
            notional=abs(delta)*exec_px
            fee=notional*commission
            if side>0:
                cash-=notional+fee
            else:
                cash+=notional-fee
            shares=desired_shares
            trades+=1
            total_cost+=fee+abs(delta)*open_px*slippage

        equity=cash+shares*close_px
        rows.append((idx,equity,shares,cash))

    out=pd.DataFrame(rows,columns=["DATE","EQUITY","SHARES","CASH"]).set_index("DATE")
    ret=out.EQUITY.pct_change().fillna(0)
    peak=out.EQUITY.cummax()
    dd=out.EQUITY/peak-1
    annualized=(1+ret).prod()**(252/max(len(ret),1))-1
    return {
        "equity":out.EQUITY,
        "returns":ret,
        "total_return":float(out.EQUITY.iloc[-1]/initial_cash-1),
        "annual_return":float(annualized),
        "annual_vol":float(ret.std()*np.sqrt(252)),
        "max_drawdown":float(dd.min()),
        "sharpe":float(ret.mean()/ret.std()*np.sqrt(252)) if ret.std()>0 else 0.0,
        "cost_total":float(total_cost),
        "trades":int(trades),
        "final_equity":float(out.EQUITY.iloc[-1]),
    }

def strategy_backtest(df, signal_col="SIGNAL", commission=0.0005, slippage=0.0005):
    return realistic_backtest(df,signal_col,commission,slippage,execution_delay=1)

def buy_hold(df, initial_cash=1_000_000, commission=0.0005, slippage=0.0005):
    x=df.sort_index()
    if len(x)<2:return {"total_return":0.0,"equity":pd.Series(dtype=float)}
    first=float(x.OPEN.iloc[0])*(1+slippage)
    last=float(x.CLOSE.iloc[-1])*(1-slippage)
    shares=initial_cash/first
    fee=initial_cash*commission
    final=shares*last
    final-=final*commission
    equity=initial_cash*((x.CLOSE/first))
    return {"total_return":float(final/initial_cash-1),"equity":equity,
            "final_equity":float(final),"cost_total":float(fee+final*commission)}
