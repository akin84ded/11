import sys, pandas as pd, numpy as np
from analytics import indicators,risk,technical_score
from ml_model import fit_predict,walk_forward,dataset
from backtest import strategy_backtest,realistic_backtest
from portfolio import returns_matrix,weights_inverse_vol,portfolio_stats
from bot_service import handle
from bot_poller import extract_command
from moex import _block

def assert_true(v):
    if not v: raise AssertionError(v)

def assert_keys(d,ks):
    for k in ks: assert_true(k in d)

np.random.seed(42)
n=650
idx=pd.bdate_range("2020-01-01",periods=n)
close=100*np.exp(np.cumsum(np.random.normal(.0004,.012,n)))
df=pd.DataFrame({"OPEN":close*(1+np.random.normal(0,.003,n)),
"HIGH":close*(1+np.abs(np.random.normal(0,.006,n))),
"LOW":close*(1-np.abs(np.random.normal(0,.006,n))),
"CLOSE":close,"VOLUME":np.random.randint(10000,100000,n),
"VALUE":close*np.random.randint(10000,100000,n)},index=idx)

def chk(name,fn):
    try: fn(); print("PASS",name)
    except Exception as e: print("FAIL",name,e); raise

x=indicators(df)
chk("analytics",lambda: (assert_true:=None) if not x.empty else (_ for _ in ()).throw(Exception("empty")))
chk("risk",lambda: risk(x))
m=fit_predict(x,20)
chk("ml",lambda: assert_keys(m,["prob_up","expected_return","metrics"]))
wf=walk_forward(x,20,min_train=250,step=50)
chk("walk_forward",lambda: wf)
x2=x.dropna().copy(); x2["SIGNAL"]=(x2.CLOSE>x2.SMA20).astype(int)
chk("backtest",lambda: strategy_backtest(x2))
frames={"A":x,"B":x.copy()}; ret=returns_matrix(frames); w=weights_inverse_vol(ret)
chk("portfolio",lambda: portfolio_stats(ret,w))
watch=["SBER"]
chk("bot commands",lambda: assert_true(handle("/add GAZP",watch).find("GAZP")>=0))
chk("parser telegram",lambda: assert_true(extract_command("telegram",{"message":{"text":"/ping"}})=="/ping"))
js={"history":{"columns":["BOARDID","SECID"],"data":[["TQBR","SBER"]]}}
chk("moex parser",lambda: assert_true(len(_block(js,"history"))==1))

# leakage guard: targets must use future returns, features only current/past.
d=dataset(x,20)
chk("leakage guard",lambda: assert_true("TARGET_RET" in d and d.index.max() <= x.index.max()))


def test_execution_delay_and_costs():
    z=df.copy()
    z["SIGNAL"]=0
    z.iloc[100:300,z.columns.get_loc("SIGNAL")]=1
    a=realistic_backtest(z,commission=0,slippage=0,execution_delay=1)
    b=realistic_backtest(z,commission=.005,slippage=.005,execution_delay=1)
    assert_true(b["final_equity"] <= a["final_equity"]+1e-8)
    assert_true(a["trades"]>0)

chk("realistic execution",test_execution_delay_and_costs)

print("ALL COMPLETE TESTS PASSED")

