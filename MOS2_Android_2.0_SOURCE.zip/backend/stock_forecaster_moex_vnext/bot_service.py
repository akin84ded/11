import os,re
from config import DEFAULT_WATCHLIST
from bot_poller import TelegramPoller,MaxPoller,extract_command,command_help
from notifications import send_telegram,send_max

def handle(cmd,watch):
    p=cmd.split()
    if not p:return "Введите /help"
    c=p[0].split("@")[0].lower()
    if c in ("/start","/help"):return command_help()
    if c=="/ping":return "pong"
    if c=="/status":return "OK. Бумаг: "+str(len(watch))
    if c=="/signals":return "Сигналы рассчитывает monitor_service.py"
    if c=="/portfolio":return "Портфель: inverse-volatility доступен в приложении."
    if c=="/add" and len(p)>1:
        s=p[1].upper()
        if s not in watch and len(watch)<10:watch.append(s)
        return "Watchlist: "+", ".join(watch)
    if c=="/remove" and len(p)>1:
        s=p[1].upper()
        if s in watch:watch.remove(s)
        return "Watchlist: "+", ".join(watch)
    return "Неизвестная команда. /help"

def main():
    watch=list(DEFAULT_WATCHLIST)
    tt=os.getenv("TELEGRAM_BOT_TOKEN"); tc=os.getenv("TELEGRAM_CHAT_ID")
    mt=os.getenv("MAX_BOT_TOKEN"); mc=os.getenv("MAX_CHAT_ID")
    tp=TelegramPoller(tt) if tt else None; mp=MaxPoller(mt) if mt else None
    while True:
        did=False
        if tp:
            try:
                for u in tp.poll():
                    did=True; ans=handle(extract_command("telegram",u),watch)
                    chat=u.get("message",{}).get("chat",{}).get("id",tc)
                    send_telegram(ans,tt,chat)
            except Exception: pass
        if mp:
            try:
                for u in mp.poll():
                    did=True; ans=handle(extract_command("max",u),watch)
                    send_max(ans,mt,mc)
            except Exception: pass
        if not did: continue

if __name__=="__main__": main()
