import time, requests, pandas as pd

BASE="https://iss.moex.com/iss"
SESSION_MAP={"0":"morning","1":"main","2":"evening","3":"full","5":"weekend"}

class MOEXError(RuntimeError): pass

def _get(path, params=None, retries=3, timeout=20):
    url=BASE+path
    last=None
    for i in range(retries):
        try:
            r=requests.get(url, params=params or {}, timeout=timeout,
                           headers={"User-Agent":"StockForecaster/1.0"})
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last=e
            if i+1<retries:
                time.sleep(0.5*(2**i))
    raise MOEXError(f"MOEX ISS request failed: {last}")

def _block(js, name):
    b=js.get(name, {})
    return pd.DataFrame(b.get("data", []), columns=b.get("columns", []))

def history(secid, start=None, end=None, board="TQBR", session="3",
            market="shares", engine="stock"):
    path=f"/history/engines/{engine}/markets/{market}/boards/{board}/securities/{secid}.json"
    base_params={"iss.meta":"off","limit":100}
    if start: base_params["from"]=start
    if end: base_params["till"]=end

    chunks=[]
    offset=0
    for _ in range(1000):
        params=dict(base_params)
        params["start"]=offset
        js=_get(path,params)

        # IMPORTANT: actual quotes live in `history`, not `history.cursor`.
        part=_block(js,"history")
        if part.empty:
            break
        chunks.append(part)

        cursor=_block(js,"history.cursor")
        if not cursor.empty and {"INDEX","TOTAL","PAGESIZE"}.issubset(cursor.columns):
            row=cursor.iloc[0]
            index=int(row["INDEX"]); total=int(row["TOTAL"]); page=int(row["PAGESIZE"])
            if page<=0 or index+page>=total:
                break
            offset=index+page
        else:
            if len(part)<base_params["limit"]:
                break
            offset += len(part)

    if not chunks:
        return pd.DataFrame()

    df=pd.concat(chunks,ignore_index=True)
    if "BOARDID" in df.columns:
        df=df[df["BOARDID"].eq(board)].copy()

    for c in ("TRADINGSESSION","SESSION","SESSIONNUMBER"):
        if c in df.columns and session is not None:
            df=df[df[c].astype(str).eq(str(session))].copy()
            break

    for c in ["OPEN","LOW","HIGH","CLOSE","LEGALCLOSEPRICE",
              "PREVLEGALCLOSEPRICE","VWAP","VALUE","NUMTRADES","VOLUME"]:
        if c in df.columns:
            df[c]=pd.to_numeric(df[c],errors="coerce")

    if "TRADEDATE" in df.columns:
        df["TRADEDATE"]=pd.to_datetime(df["TRADEDATE"],errors="coerce")
        df=df.dropna(subset=["TRADEDATE"]).sort_values("TRADEDATE")
        df=df.drop_duplicates("TRADEDATE",keep="last").set_index("TRADEDATE")
    return df

def marketdata(secid, board="TQBR"):
    path=f"/engines/stock/markets/shares/boards/{board}/securities/{secid}.json"
    js=_get(path,{"iss.meta":"off"})
    for name in ("securities","marketdata"):
        df=_block(js,name)
        if not df.empty:
            return df
    return pd.DataFrame()

def candles(secid, interval=24, board="TQBR", start=None, end=None):
    path=f"/engines/stock/markets/shares/boards/{board}/securities/{secid}/candles.json"
    p={"iss.meta":"off","interval":interval,"limit":5000}
    if start:p["from"]=start
    if end:p["till"]=end
    return _block(_get(path,p),"candles")


def securities(board="TQBR", market="shares", engine="stock", limit=100):
    """Return all securities traded on a board, using ISS pagination."""
    path=f"/engines/{engine}/markets/{market}/boards/{board}/securities.json"
    chunks=[]
    offset=0
    for _ in range(100):
        js=_get(path, {"iss.meta":"off", "limit":limit, "start":offset})
        part=_block(js, "securities")
        if part.empty:
            break
        chunks.append(part)
        cursor=_block(js, "securities.cursor")
        if not cursor.empty and {"INDEX","TOTAL","PAGESIZE"}.issubset(cursor.columns):
            row=cursor.iloc[0]
            index,total,page=int(row["INDEX"]),int(row["TOTAL"]),int(row["PAGESIZE"])
            if page<=0 or index+page>=total:
                break
            offset=index+page
        else:
            if len(part)<limit: break
            offset += len(part)
    if not chunks: return pd.DataFrame()
    result=pd.concat(chunks,ignore_index=True)
    if "SECID" in result:
        result=result.dropna(subset=["SECID"]).drop_duplicates("SECID")
    return result
