import requests

def send_telegram(text,token,chat_id,disable_notification=False):
    if not token or not chat_id:return False,"Telegram not configured"
    u=f"https://api.telegram.org/bot{token}/sendMessage"
    r=requests.post(u,json={"chat_id":chat_id,"text":text,
                            "disable_notification":disable_notification},timeout=15)
    r.raise_for_status(); return True,r.json()

def send_max(text,token,chat_id,notify=True):
    if not token or not chat_id:return False,"MAX not configured"
    u="https://platform-api2.max.ru/messages"
    r=requests.post(u,headers={"Authorization":token},
                    json={"chat_id":chat_id,"text":text,"notify":notify,
                          "format":"markdown"},timeout=15)
    r.raise_for_status(); return True,r.json()

def send_all(text,telegram=None,maxx=None):
    out=[]
    if telegram:
        try: out.append(("telegram",)+send_telegram(text,*telegram))
        except Exception as e: out.append(("telegram",False,str(e)))
    if maxx:
        try: out.append(("max",)+send_max(text,*maxx))
        except Exception as e: out.append(("max",False,str(e)))
    return out
