import os
import subprocess
import sys
import threading
from api_server import serve

port = os.getenv("PORT", "8501")
api_port = int(os.getenv("API_PORT", "8502"))
threading.Thread(target=serve, kwargs={"host":"0.0.0.0","port":api_port}, daemon=True).start()
args = [
    sys.executable, "-m", "streamlit", "run", "app.py",
    "--server.address", "0.0.0.0",
    "--server.port", port,
    "--server.headless", "true",
    "--browser.gatherUsageStats", "false",
]
raise SystemExit(subprocess.call(args))
