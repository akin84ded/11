import json
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd

from trade_levels import trade_levels
from portfolio import weights_inverse_vol, portfolio_stats
import moex
import api_server
from http.server import ThreadingHTTPServer
import threading, urllib.request

def check(name, fn):
    fn()
    print("PASS", name)

idx=pd.bdate_range("2022-01-01",periods=260)
close=pd.Series(100*np.exp(np.cumsum(np.random.default_rng(7).normal(0,.01,len(idx)))),index=idx)
frame=pd.DataFrame({"CLOSE":close,"ATR14":close*0.02},index=idx)

def test_levels():
    levels=trade_levels(frame)
    assert levels["entry_zone_low"] < levels["price"] < levels["entry_zone_high"]
    assert levels["stop_loss"] < levels["price"] < levels["take_profit_2"]
    assert levels["reward_risk"] == 1.5

def test_caps():
    rets=pd.DataFrame({f"S{i}":np.random.default_rng(i).normal(0,.01+i*.002,500) for i in range(8)})
    weights=weights_inverse_vol(rets,max_weight=.25)
    assert abs(weights.sum()-1)<1e-9
    assert weights.max() <= .25+1e-9
    stats=portfolio_stats(rets,weights)
    assert "max_drawdown" in stats

def test_small_portfolio_feasible():
    rets=pd.DataFrame({"A":np.random.default_rng(1).normal(0,.01,100),
                       "B":np.random.default_rng(2).normal(0,.02,100)})
    w=weights_inverse_vol(rets,max_weight=.25)
    assert abs(w.sum()-1)<1e-9
    assert w.max() <= .500001



def test_android_signals_api():
    temp=Path(tempfile.mkdtemp())/"monitor_state.json"
    temp.write_text(json.dumps({"SBER":{"signal":"BUY","price":123.4,"prob_up":0.7},
                                "BAD":{"error":"unavailable"}}),encoding="utf-8")
    old_path=api_server.STATE_PATH
    server=ThreadingHTTPServer(("127.0.0.1",0),api_server.Handler)
    api_server.STATE_PATH=temp
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{server.server_port}/api/signals",timeout=3) as response:
            data=json.loads(response.read().decode("utf-8"))
        assert data=={"SBER":{"signal":"BUY","price":123.4,"prob_up":0.7,"expected_return":None,"score":None}}
    finally:
        server.shutdown()
        server.server_close()
        api_server.STATE_PATH=old_path

def test_securities_pagination():
    calls=[]
    def fake(path,params):
        calls.append(params["start"])
        if params["start"]==0:
            return {"securities":{"columns":["SECID"],"data":[["AAA"],["BBB"]]},
                    "securities.cursor":{"columns":["INDEX","TOTAL","PAGESIZE"],"data":[[0,3,2]]}}
        return {"securities":{"columns":["SECID"],"data":[["CCC"]]},
                "securities.cursor":{"columns":["INDEX","TOTAL","PAGESIZE"],"data":[[2,3,2]]}}
    old=moex._get
    moex._get=fake
    try:
        result=moex.securities(limit=2)
        assert result.SECID.tolist()==["AAA","BBB","CCC"]
        assert calls==[0,2]
    finally:
        moex._get=old

check("ATR trade levels and ordering",test_levels)
check("smart portfolio sum and concentration cap",test_caps)
check("small portfolio feasible weights",test_small_portfolio_feasible)
check("MOEX securities pagination",test_securities_pagination)
check("Android signals API",test_android_signals_api)
print("ALL MOS2 2.0 TESTS PASSED")
